// Clase virtual 14.04.2020.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "conio.h"
#include <string>

using namespace std;

void main()
{
	int longitud,cont,pos;
	char aux;
	
	string var1, var2, nombre; //Declarar strings
	
	cout<<endl<<"Ejemplo de uso de getline para ingresar cadena de caracteres";
	cout<<endl<<"Ingrese un nombre: ";
	getline(cin,nombre);
	cout<<nombre;
	getch();
}
