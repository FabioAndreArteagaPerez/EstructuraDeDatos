#pragma once
#include <iostream>
#include "Pila.h"

namespace PilaForm {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Pila P1;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  Grilla;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;



	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtObj;
	private: System::Windows::Forms::Button^  btnDesapilar;





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtObj = (gcnew System::Windows::Forms::TextBox());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// Grilla
			// 
			this->Grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grilla->Location = System::Drawing::Point(57, 62);
			this->Grilla->Name = L"Grilla";
			this->Grilla->Size = System::Drawing::Size(139, 150);
			this->Grilla->TabIndex = 0;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Pila";
			this->Column1->Name = L"Column1";
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(178, 17);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 6;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(19, 22);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(38, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Objeto";
			// 
			// txtObj
			// 
			this->txtObj->Location = System::Drawing::Point(72, 19);
			this->txtObj->Name = L"txtObj";
			this->txtObj->Size = System::Drawing::Size(100, 20);
			this->txtObj->TabIndex = 4;
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(212, 118);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(75, 23);
			this->btnDesapilar->TabIndex = 7;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			this->btnDesapilar->Click += gcnew System::EventHandler(this, &Form1::btnDesapilar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(355, 261);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtObj);
			this->Controls->Add(this->Grilla);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento;
			 elemento=System::Convert::ToInt32(txtObj->Text);
			 P1.Set_cima(pos+1);
			 if(P1.Apilar(elemento,pos))
			 {pos++;
			 P1.Set_cima(pos+1);
			 Grilla->ColumnCount=1;
			 Grilla->ColumnCount=P1.Get_cima();
			 double val;
			 for(int i=P1.Get_cima()-1;i>=0;i--)
			 {val=P1.Get_pila(i);
			 Grilla->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(val);
			 }
			 }
		 }
private: System::Void btnDesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 P1.Desapilar();
			 Grilla->RowCount=P1.Get_cima();
		 }
};
}

