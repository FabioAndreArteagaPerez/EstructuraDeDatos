#pragma once
#define MAX 50
class Pila
{
private:
	int pila[MAX];
    int cima;
public:
	Pila(void);
	~Pila(void);
	int Get_cima();
	void Set_cima(int c);
	int Get_pila(int pos);
	void Set_pila(int pos,int elemento);
	bool Apilar(int elemento,int pos);
    bool Desapilar();     
    bool PilaVacia();
};