#include "StdAfx.h"
#include "Pila.h"
#include <iostream>

using namespace std;
Pila::Pila(void)
{
	cima=-1;
	pila[MAX]=0;
}


Pila::~Pila(void)
{
}

int Pila::Get_cima()
{return cima;}

void Pila::Set_cima(int c)
{cima=c;}

int Pila::Get_pila(int pos)
{return pila[pos];}

void Pila::Set_pila(int pos,int elemento)
{pila[pos]=elemento;}

bool Pila::Apilar(int elemento,int pos)
{
if(cima == MAX-1)
	{
	return false;
	}
	else
     {
		pila[pos] = elemento;
		return true;
	 }
}

bool Pila::Desapilar()
{
	if(Get_cima() == -1)
		{
		return false;
		}else
			{
			cima--;
			Set_cima(cima);
			return true;
			}
}   

bool Pila::PilaVacia()
{
	if(Get_cima() == -1)
		return true;
	else
		return false;
}

