#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;

class NODO
{
	string nombre_proceso;
	int numero_proceso;
public:
	NODO(void);
	string Get_nombre_proceso();
	int Get_numero_proceso();
	void Set_nombre_proceso(string);
	void Set_numero_proceso(int);
	bool Mayor_nombre(NODO);
	bool Igual_nombre(NODO);
	bool Mayor_numero(NODO);
	bool Igual_numero(NODO);
};

