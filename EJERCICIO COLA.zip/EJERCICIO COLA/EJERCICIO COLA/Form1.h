#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "OPERACIONES.h"
using namespace System::Windows::Forms;
using namespace std;
using namespace msclr::interop;
using namespace std;
namespace EJERCICIOCOLA {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	OPERACIONES op_colita;
	int evento=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla_cola1;
	protected: 
	private: System::Windows::Forms::DataGridView^  grilla_cola2;
	private: System::Windows::Forms::TextBox^  ttamano;
	private: System::Windows::Forms::Button^  bTAMANO;
	private: System::Windows::Forms::Button^  bInsertar;
	private: System::Windows::Forms::Button^  bMostrar;
	private: System::Windows::Forms::TextBox^  tnumero;

	private: System::Windows::Forms::Button^  bINSERTAR_UNO_A_UNO;
	private: System::Windows::Forms::TextBox^  tnombre;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  bELEMINAR_PARES;
	private: System::Windows::Forms::Button^  bELIMINAR;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla_cola1 = (gcnew System::Windows::Forms::DataGridView());
			this->grilla_cola2 = (gcnew System::Windows::Forms::DataGridView());
			this->ttamano = (gcnew System::Windows::Forms::TextBox());
			this->bTAMANO = (gcnew System::Windows::Forms::Button());
			this->bInsertar = (gcnew System::Windows::Forms::Button());
			this->bMostrar = (gcnew System::Windows::Forms::Button());
			this->tnumero = (gcnew System::Windows::Forms::TextBox());
			this->bINSERTAR_UNO_A_UNO = (gcnew System::Windows::Forms::Button());
			this->tnombre = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->bELEMINAR_PARES = (gcnew System::Windows::Forms::Button());
			this->bELIMINAR = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola2))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla_cola1
			// 
			this->grilla_cola1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_cola1->Location = System::Drawing::Point(25, 12);
			this->grilla_cola1->Name = L"grilla_cola1";
			this->grilla_cola1->Size = System::Drawing::Size(740, 93);
			this->grilla_cola1->TabIndex = 0;
			// 
			// grilla_cola2
			// 
			this->grilla_cola2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_cola2->Location = System::Drawing::Point(25, 261);
			this->grilla_cola2->Name = L"grilla_cola2";
			this->grilla_cola2->Size = System::Drawing::Size(740, 102);
			this->grilla_cola2->TabIndex = 1;
			this->grilla_cola2->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::grilla_cola2_CellContentClick);
			// 
			// ttamano
			// 
			this->ttamano->Location = System::Drawing::Point(236, 145);
			this->ttamano->Name = L"ttamano";
			this->ttamano->Size = System::Drawing::Size(100, 20);
			this->ttamano->TabIndex = 2;
			// 
			// bTAMANO
			// 
			this->bTAMANO->Location = System::Drawing::Point(236, 171);
			this->bTAMANO->Name = L"bTAMANO";
			this->bTAMANO->Size = System::Drawing::Size(75, 23);
			this->bTAMANO->TabIndex = 3;
			this->bTAMANO->Text = L"Tamano";
			this->bTAMANO->UseVisualStyleBackColor = true;
			this->bTAMANO->Click += gcnew System::EventHandler(this, &Form1::bTAMANO_Click);
			// 
			// bInsertar
			// 
			this->bInsertar->Location = System::Drawing::Point(35, 146);
			this->bInsertar->Name = L"bInsertar";
			this->bInsertar->Size = System::Drawing::Size(75, 23);
			this->bInsertar->TabIndex = 4;
			this->bInsertar->Text = L"Insertar";
			this->bInsertar->UseVisualStyleBackColor = true;
			this->bInsertar->Click += gcnew System::EventHandler(this, &Form1::bInsertar_Click);
			// 
			// bMostrar
			// 
			this->bMostrar->Location = System::Drawing::Point(131, 146);
			this->bMostrar->Name = L"bMostrar";
			this->bMostrar->Size = System::Drawing::Size(75, 23);
			this->bMostrar->TabIndex = 5;
			this->bMostrar->Text = L"Mostrar";
			this->bMostrar->UseVisualStyleBackColor = true;
			this->bMostrar->Click += gcnew System::EventHandler(this, &Form1::bMostrar_Click);
			// 
			// tnumero
			// 
			this->tnumero->Location = System::Drawing::Point(371, 149);
			this->tnumero->Name = L"tnumero";
			this->tnumero->Size = System::Drawing::Size(100, 20);
			this->tnumero->TabIndex = 6;
			// 
			// bINSERTAR_UNO_A_UNO
			// 
			this->bINSERTAR_UNO_A_UNO->Location = System::Drawing::Point(371, 188);
			this->bINSERTAR_UNO_A_UNO->Name = L"bINSERTAR_UNO_A_UNO";
			this->bINSERTAR_UNO_A_UNO->Size = System::Drawing::Size(145, 23);
			this->bINSERTAR_UNO_A_UNO->TabIndex = 7;
			this->bINSERTAR_UNO_A_UNO->Text = L"Insetar uno a uno";
			this->bINSERTAR_UNO_A_UNO->UseVisualStyleBackColor = true;
			this->bINSERTAR_UNO_A_UNO->Click += gcnew System::EventHandler(this, &Form1::bINSERTAR_UNO_A_UNO_Click);
			// 
			// tnombre
			// 
			this->tnombre->Location = System::Drawing::Point(508, 144);
			this->tnombre->Name = L"tnombre";
			this->tnombre->Size = System::Drawing::Size(100, 20);
			this->tnombre->TabIndex = 8;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(371, 130);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 9;
			this->label1->Text = L"numero";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(508, 125);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(42, 13);
			this->label2->TabIndex = 10;
			this->label2->Text = L"nombre";
			// 
			// bELEMINAR_PARES
			// 
			this->bELEMINAR_PARES->Location = System::Drawing::Point(586, 188);
			this->bELEMINAR_PARES->Name = L"bELEMINAR_PARES";
			this->bELEMINAR_PARES->Size = System::Drawing::Size(103, 23);
			this->bELEMINAR_PARES->TabIndex = 11;
			this->bELEMINAR_PARES->Text = L"Eliminar pares";
			this->bELEMINAR_PARES->UseVisualStyleBackColor = true;
			this->bELEMINAR_PARES->Click += gcnew System::EventHandler(this, &Form1::bELEMINAR_PARES_Click);
			// 
			// bELIMINAR
			// 
			this->bELIMINAR->Location = System::Drawing::Point(35, 208);
			this->bELIMINAR->Name = L"bELIMINAR";
			this->bELIMINAR->Size = System::Drawing::Size(105, 23);
			this->bELIMINAR->TabIndex = 12;
			this->bELIMINAR->Text = L"Eliminar";
			this->bELIMINAR->UseVisualStyleBackColor = true;
			this->bELIMINAR->Click += gcnew System::EventHandler(this, &Form1::bELIMINAR_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(799, 430);
			this->Controls->Add(this->bELIMINAR);
			this->Controls->Add(this->bELEMINAR_PARES);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->tnombre);
			this->Controls->Add(this->bINSERTAR_UNO_A_UNO);
			this->Controls->Add(this->tnumero);
			this->Controls->Add(this->bMostrar);
			this->Controls->Add(this->bInsertar);
			this->Controls->Add(this->bTAMANO);
			this->Controls->Add(this->ttamano);
			this->Controls->Add(this->grilla_cola2);
			this->Controls->Add(this->grilla_cola1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_cola2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void grilla_cola2_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
private: System::Void bTAMANO_Click(System::Object^  sender, System::EventArgs^  e) 
		 
		 {
			 grilla_cola1->ColumnCount=System::Convert::ToInt32(ttamano->Text);
			 grilla_cola1->RowCount=2;
			 evento=1;

		 }
private: System::Void bInsertar_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
		   
		 if(evento>=1)
		 {
		     op_colita.Guardar_grilla_cola(grilla_cola1);

		 }
		 evento=1;
		 }
private: System::Void bMostrar_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
		   if(evento>=1)
		 {
		     op_colita.Guardar_cola_grilla(grilla_cola2);

		 }
		 evento=1;
		 
		 }
private: System::Void bINSERTAR_UNO_A_UNO_Click(System::Object^  sender, System::EventArgs^  e) 
		 
		 {
             NODO informacion;
			 informacion.Set_numero_proceso(System::Convert::ToInt32(tnumero->Text));
			 informacion.Set_nombre_proceso(marshal_as<std::string>(System::Convert::ToString(tnombre->Text)));
			 op_colita.Insertar(informacion);

		 }
private: System::Void bELEMINAR_PARES_Click(System::Object^  sender, System::EventArgs^  e) 
		 
		 {
			 op_colita.Eliminar_numero_pares();
		 }
private: System::Void bELIMINAR_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
		     NODO informacion;
			 op_colita.Eliminar(informacion);
		 
		 }
};
}

