#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "NODO.h"
using namespace std;
using namespace msclr::interop;
using namespace std;
const int NC=5;
class COLA
{
	NODO cola[NC];
	int frente;
	int final;
public:
	COLA(void);
	bool Cola_vacia();
	bool Cola_llena();
	bool Insertar(NODO);
	bool Eliminar(NODO &);
	int  Get_frente();

	COLA This_cola();
	void This_cola(COLA);
};

