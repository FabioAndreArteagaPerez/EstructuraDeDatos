#pragma once
#include "conio.h"
#include <iostream>
#define MAX 100
class pila
{
private:
		int Pila[MAX];
		int cima;
public:
		pila(void);
		~pila(void);
		bool Apilar(int &elemento);
        bool Desapilar();
        bool CimaPila(int &elemento);
        void LimpiarPila();
        void VerPila();          
        bool PilaVacia();
        bool Iguales(pila p);
};


