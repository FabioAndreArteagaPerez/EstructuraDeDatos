#pragma once
#include "Operaciones.h"

namespace MatricesEjercicio7 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>

	Operaciones datos;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dgvSucursales;
	private: System::Windows::Forms::TextBox^  tbCantidadSuc;
	private: System::Windows::Forms::Button^  btnAsignarSucursales;
	private: System::Windows::Forms::Button^  btnTotalVentas;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btnPeorMes;
	private: System::Windows::Forms::Button^  btnGuardar;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dgvSucursales = (gcnew System::Windows::Forms::DataGridView());
			this->tbCantidadSuc = (gcnew System::Windows::Forms::TextBox());
			this->btnAsignarSucursales = (gcnew System::Windows::Forms::Button());
			this->btnTotalVentas = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btnPeorMes = (gcnew System::Windows::Forms::Button());
			this->btnGuardar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvSucursales))->BeginInit();
			this->SuspendLayout();
			// 
			// dgvSucursales
			// 
			this->dgvSucursales->AllowUserToAddRows = false;
			this->dgvSucursales->AllowUserToDeleteRows = false;
			this->dgvSucursales->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvSucursales->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvSucursales->Location = System::Drawing::Point(13, 13);
			this->dgvSucursales->Name = L"dgvSucursales";
			this->dgvSucursales->Size = System::Drawing::Size(265, 212);
			this->dgvSucursales->TabIndex = 0;
			this->dgvSucursales->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dgvSucursales_CellContentClick);
			// 
			// tbCantidadSuc
			// 
			this->tbCantidadSuc->Location = System::Drawing::Point(284, 13);
			this->tbCantidadSuc->Name = L"tbCantidadSuc";
			this->tbCantidadSuc->Size = System::Drawing::Size(76, 20);
			this->tbCantidadSuc->TabIndex = 1;
			// 
			// btnAsignarSucursales
			// 
			this->btnAsignarSucursales->Location = System::Drawing::Point(367, 9);
			this->btnAsignarSucursales->Name = L"btnAsignarSucursales";
			this->btnAsignarSucursales->Size = System::Drawing::Size(94, 23);
			this->btnAsignarSucursales->TabIndex = 2;
			this->btnAsignarSucursales->Text = L"Sucursales";
			this->btnAsignarSucursales->UseVisualStyleBackColor = true;
			this->btnAsignarSucursales->Click += gcnew System::EventHandler(this, &Form1::btnAsignarSucursales_Click);
			// 
			// btnTotalVentas
			// 
			this->btnTotalVentas->Location = System::Drawing::Point(285, 78);
			this->btnTotalVentas->Name = L"btnTotalVentas";
			this->btnTotalVentas->Size = System::Drawing::Size(176, 32);
			this->btnTotalVentas->TabIndex = 3;
			this->btnTotalVentas->Text = L"Total ventas";
			this->btnTotalVentas->UseVisualStyleBackColor = true;
			this->btnTotalVentas->Click += gcnew System::EventHandler(this, &Form1::btnTotalVentas_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(285, 117);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(176, 32);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Total ventas/sucursal";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(285, 156);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(176, 32);
			this->button2->TabIndex = 5;
			this->button2->Text = L"Mejor sucursal";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btnPeorMes
			// 
			this->btnPeorMes->Location = System::Drawing::Point(285, 193);
			this->btnPeorMes->Name = L"btnPeorMes";
			this->btnPeorMes->Size = System::Drawing::Size(176, 32);
			this->btnPeorMes->TabIndex = 6;
			this->btnPeorMes->Text = L"Peor mes";
			this->btnPeorMes->UseVisualStyleBackColor = true;
			this->btnPeorMes->Click += gcnew System::EventHandler(this, &Form1::btnPeorMes_Click);
			// 
			// btnGuardar
			// 
			this->btnGuardar->Location = System::Drawing::Point(285, 40);
			this->btnGuardar->Name = L"btnGuardar";
			this->btnGuardar->Size = System::Drawing::Size(176, 32);
			this->btnGuardar->TabIndex = 7;
			this->btnGuardar->Text = L"Guardar datos";
			this->btnGuardar->UseVisualStyleBackColor = true;
			this->btnGuardar->Click += gcnew System::EventHandler(this, &Form1::btnGuardar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(473, 237);
			this->Controls->Add(this->btnGuardar);
			this->Controls->Add(this->btnPeorMes);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnTotalVentas);
			this->Controls->Add(this->btnAsignarSucursales);
			this->Controls->Add(this->tbCantidadSuc);
			this->Controls->Add(this->dgvSucursales);
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Ejercicio 7";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvSucursales))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dgvSucursales_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
	private: System::Void btnAsignarSucursales_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.setFilas(Convert::ToInt32(tbCantidadSuc->Text));
				 dgvSucursales -> RowCount = datos.getFilas();
				 dgvSucursales -> ColumnCount = 12;
			 }
	private: System::Void btnTotalVentas_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.totalVentas();
			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.totalVentasSucursal(dgvSucursales);
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.mejorSucursal();
			 }
	private: System::Void btnPeorMes_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.peorMes();
			 }
	private: System::Void btnGuardar_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.guardarMatriz(dgvSucursales);
			 }
};
}

