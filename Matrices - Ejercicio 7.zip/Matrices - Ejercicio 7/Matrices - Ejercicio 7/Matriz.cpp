#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	filas = 0;
	for(int i=0; i<N; i++){
		for(int j=0; j<12; j++){
			matriz[i][j] = 0;
		}
	}
}

void Matriz::setFilas(int _filas){
	filas = _filas;
}

void Matriz::setValorMatriz(int f, int c, int valor){
	matriz[f][c] = valor;
}

int Matriz::getFilas(){
	return filas;
}

int Matriz::getValorMatriz(int f, int c){
	return matriz[f][c];
}

