#pragma once
#include "Matriz.h"
#include <msclr\marshal_cppstd.h>
#include <string>

using namespace std;
using namespace System;
using namespace System::Windows::Forms;
using namespace msclr::interop;

class Operaciones : public Matriz
{
	void mostrarMes(int);
public:
	Operaciones(void);

	void guardarMatriz(DataGridView^);

	void totalVentas();
	void totalVentasSucursal(DataGridView^);
	void mejorSucursal();
	void peorMes();
};

