#pragma once

const int N = 20;

class Matriz
{
	int filas;
	int matriz[N][12];
public:
	Matriz(void);
	// LAS COLUMNAS NO SE TOMAN EN CUENTA PORQUE SIEMPRE VAN A SER 12
	void setFilas(int);
	void setValorMatriz(int, int, int);
	int getFilas();
	int getValorMatriz(int, int);
};

