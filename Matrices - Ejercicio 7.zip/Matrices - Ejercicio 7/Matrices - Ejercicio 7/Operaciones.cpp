#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
	Matriz();
}

void Operaciones::mostrarMes(int peorMes){
	switch(peorMes){
	case 0:{
				MessageBox::Show("Peor mes: Enero", "Resultado");
				break;
		   }
	case 1:{
				MessageBox::Show("Peor mes: Febrero", "Resultado");
				break;
		   }
	case 2:{
				MessageBox::Show("Peor mes: Marzo", "Resultado");
				break;
		   }
	case 3:{
				MessageBox::Show("Peor mes: Abril", "Resultado");
				break;
		   }
	case 4:{
				MessageBox::Show("Peor mes: Mayo", "Resultado");
				break;
		   }
	case 5:{
				MessageBox::Show("Peor mes: Junio", "Resultado");
				break;
		   }
	case 6:{
				MessageBox::Show("Peor mes: Julio", "Resultado");
				break;
		   }
	case 7:{
				MessageBox::Show("Peor mes: Agosto", "Resultado");
				break;
		   }
	case 8:{
				MessageBox::Show("Peor mes: Septiembre", "Resultado");
				break;
		   }
	case 9:{
				MessageBox::Show("Peor mes: Octubre", "Resultado");
				break;
		   }
	case 10:{
				MessageBox::Show("Peor mes: Noviembre", "Resultado");
				break;
		   }
	case 11:{
				MessageBox::Show("Peor mes: Diciembre", "Resultado");
				break;
		   }
	default:{
				MessageBox::Show("No existe un peor mes", "Resultado");
				break;
			}
	}
}

void Operaciones::guardarMatriz(DataGridView^ dgv){
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<12; j++)
			setValorMatriz(i, j, Convert::ToInt32(dgv->Rows[i]->Cells[j]->Value));
	}
}

void Operaciones::totalVentas(){
	long long int resultadoGestion = 0;
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<12; j++)
			resultadoGestion += getValorMatriz(i, j);
	}

	MessageBox::Show("Total de las ventas de la compa��a: " + Convert::ToString(resultadoGestion), "Total");
}

void Operaciones::totalVentasSucursal(DataGridView^ dgv){
	dgv -> ColumnCount = 1;

	int resParcial;
	for(int i=0; i<getFilas(); i++){
		resParcial = 0;
		for(int j=0; j<12; j++)
			resParcial += getValorMatriz(i, j);
		dgv -> Rows[i] -> Cells[0] -> Value = resParcial;
	}
}

void Operaciones::mejorSucursal(){
	int mejor = INT_MIN;  // VALOR MINIMO ASIGNABLE A UNA VARIABLE DE TIPO INT
	int resParcial = 0;
	int idSucursal = 0;

	for(int i=0; i<getFilas(); i++){
		resParcial = 0;
		for(int j=0; j<12; j++)
			resParcial += getValorMatriz(i, j);
		if(resParcial > mejor){
			mejor = resParcial;
			idSucursal = i+1;
		}
	}

	MessageBox::Show("Sucursal " + Convert::ToString(idSucursal) + ": " + Convert::ToString(mejor), "Mejor resultado");
}

void Operaciones::peorMes(){
	//string meses[] = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
					  //"Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

	int peorMes = -1;
	int resParcial;
	int menor = INT_MAX;  // VALOR MAXIMO ASIGNABLE A UNA VARIABLE DE TIPO INT

	for(int j=0; j<12; j++){
		resParcial = 0;
		for(int i=0; i<getFilas(); i++)
			resParcial += getValorMatriz(i, j);
		if(resParcial < menor){
			menor = resParcial;
			peorMes = j;
		}
	}
	
	mostrarMes(peorMes);
}