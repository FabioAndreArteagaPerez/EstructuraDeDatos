#pragma once
#include "Matriz.h"
#include "Vector.h"
#include <msclr\marshal_cppstd.h>

using namespace System;
using namespace System::Windows::Forms;
using namespace msclr::interop;

class Operaciones : public Matriz, public Vector
{
	// METODOS DEL VECTOR
	void iniciarVector(Vector&);
	bool estaVisto(Vector&, int, int);
	bool esMatrizTriangularSuperior(int&);
	void copiarMatriz(Matriz&);
	void copiarMatriz(Matriz&, int);

public:
	Operaciones(void);

	void guardarMatriz(DataGridView^);
	void mostrarMatriz(DataGridView^);
	// METODOS DE LA MATRIZ
	void limpiarMatriz();
	void eliminarRepetidos();
	void contarElementosMatrizTSuperior();
	void sumarMatrices(Matriz&);
	void restarMatrices(Matriz&);
	void multMatrices(Matriz&);
	void matrizTraspuesta();
};