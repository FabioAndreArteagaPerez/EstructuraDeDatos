#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	filas = 1;
	columnas = 1;
	for(int i=0; i<N; i++){
		for(int j=0; j<N; j++)
			matriz[i][j] = -1;
	}
}

void Matriz::setFilas(int _filas){
	filas = _filas;
}

void Matriz::setColumnas(int _columnas){
	columnas = _columnas;
}

void Matriz::setValorMatriz(int f, int c, int valor){
	matriz[f][c] = valor;
}

int Matriz::getFilas(){
	return filas;
}

int Matriz::getColumnas(){
	return columnas;
}

int Matriz::getValorMatriz(int f, int c){
	return matriz[f][c];
}
