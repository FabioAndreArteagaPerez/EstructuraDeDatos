#pragma once
#include "Operaciones.h"


namespace Matrices {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>

	Operaciones matrizA;
	Operaciones matrizB;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		void limpiarMatriz(DataGridView^ dgv){
			dgv -> RowCount = 1;
			dgv -> ColumnCount = 1;
			dgv->Rows[0]->Cells[0]->Value = "";
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  tbFilas;
	protected: 
	private: System::Windows::Forms::Button^  btnFilas;
	private: System::Windows::Forms::TextBox^  tbColumnas;

	private: System::Windows::Forms::DataGridView^  dgvMatriz;

	private: System::Windows::Forms::Button^  btnGuardarMatriz;
	private: System::Windows::Forms::Button^  btnMostrar;
	private: System::Windows::Forms::Button^  btnEliminarRepetidos;
	private: System::Windows::Forms::Button^  btnLimpiar;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::DataGridView^  dgvMatrizB;

	private: System::Windows::Forms::TextBox^  tbFilasB;

	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::TextBox^  tbColumnasB;


	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btnMult;
	private: System::Windows::Forms::Button^  btnSumar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tbFilas = (gcnew System::Windows::Forms::TextBox());
			this->btnFilas = (gcnew System::Windows::Forms::Button());
			this->tbColumnas = (gcnew System::Windows::Forms::TextBox());
			this->dgvMatriz = (gcnew System::Windows::Forms::DataGridView());
			this->btnGuardarMatriz = (gcnew System::Windows::Forms::Button());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			this->btnEliminarRepetidos = (gcnew System::Windows::Forms::Button());
			this->btnLimpiar = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btnMult = (gcnew System::Windows::Forms::Button());
			this->btnSumar = (gcnew System::Windows::Forms::Button());
			this->dgvMatrizB = (gcnew System::Windows::Forms::DataGridView());
			this->tbFilasB = (gcnew System::Windows::Forms::TextBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->tbColumnasB = (gcnew System::Windows::Forms::TextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvMatriz))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvMatrizB))->BeginInit();
			this->SuspendLayout();
			// 
			// tbFilas
			// 
			this->tbFilas->Location = System::Drawing::Point(258, 19);
			this->tbFilas->Name = L"tbFilas";
			this->tbFilas->Size = System::Drawing::Size(87, 20);
			this->tbFilas->TabIndex = 0;
			// 
			// btnFilas
			// 
			this->btnFilas->Location = System::Drawing::Point(362, 19);
			this->btnFilas->Name = L"btnFilas";
			this->btnFilas->Size = System::Drawing::Size(87, 44);
			this->btnFilas->TabIndex = 1;
			this->btnFilas->Text = L"Guardar tama�o";
			this->btnFilas->UseVisualStyleBackColor = true;
			this->btnFilas->Click += gcnew System::EventHandler(this, &Form1::btnFilas_Click);
			// 
			// tbColumnas
			// 
			this->tbColumnas->Location = System::Drawing::Point(258, 45);
			this->tbColumnas->Name = L"tbColumnas";
			this->tbColumnas->Size = System::Drawing::Size(87, 20);
			this->tbColumnas->TabIndex = 2;
			// 
			// dgvMatriz
			// 
			this->dgvMatriz->AllowUserToAddRows = false;
			this->dgvMatriz->AllowUserToDeleteRows = false;
			this->dgvMatriz->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvMatriz->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvMatriz->ColumnHeadersVisible = false;
			this->dgvMatriz->Location = System::Drawing::Point(6, 19);
			this->dgvMatriz->Name = L"dgvMatriz";
			this->dgvMatriz->RowHeadersVisible = false;
			this->dgvMatriz->Size = System::Drawing::Size(248, 150);
			this->dgvMatriz->TabIndex = 4;
			// 
			// btnGuardarMatriz
			// 
			this->btnGuardarMatriz->Location = System::Drawing::Point(260, 75);
			this->btnGuardarMatriz->Name = L"btnGuardarMatriz";
			this->btnGuardarMatriz->Size = System::Drawing::Size(87, 54);
			this->btnGuardarMatriz->TabIndex = 5;
			this->btnGuardarMatriz->Text = L"Guardar matriz";
			this->btnGuardarMatriz->UseVisualStyleBackColor = true;
			this->btnGuardarMatriz->Click += gcnew System::EventHandler(this, &Form1::btnGuardarMatriz_Click);
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(361, 75);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(88, 25);
			this->btnMostrar->TabIndex = 6;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// btnEliminarRepetidos
			// 
			this->btnEliminarRepetidos->Location = System::Drawing::Point(101, 175);
			this->btnEliminarRepetidos->Name = L"btnEliminarRepetidos";
			this->btnEliminarRepetidos->Size = System::Drawing::Size(89, 42);
			this->btnEliminarRepetidos->TabIndex = 7;
			this->btnEliminarRepetidos->Text = L"Eliminar repetidos";
			this->btnEliminarRepetidos->UseVisualStyleBackColor = true;
			this->btnEliminarRepetidos->Click += gcnew System::EventHandler(this, &Form1::btnEliminarRepetidos_Click);
			// 
			// btnLimpiar
			// 
			this->btnLimpiar->Location = System::Drawing::Point(361, 106);
			this->btnLimpiar->Name = L"btnLimpiar";
			this->btnLimpiar->Size = System::Drawing::Size(88, 23);
			this->btnLimpiar->TabIndex = 8;
			this->btnLimpiar->Text = L"Limpiar";
			this->btnLimpiar->UseVisualStyleBackColor = true;
			this->btnLimpiar->Click += gcnew System::EventHandler(this, &Form1::btnLimpiar_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(7, 175);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(88, 42);
			this->button1->TabIndex = 9;
			this->button1->Text = L"Contar elementos";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Controls->Add(this->dgvMatriz);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->tbFilas);
			this->groupBox1->Controls->Add(this->btnEliminarRepetidos);
			this->groupBox1->Controls->Add(this->btnLimpiar);
			this->groupBox1->Controls->Add(this->btnMostrar);
			this->groupBox1->Controls->Add(this->tbColumnas);
			this->groupBox1->Controls->Add(this->btnFilas);
			this->groupBox1->Controls->Add(this->btnGuardarMatriz);
			this->groupBox1->Location = System::Drawing::Point(12, 11);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(455, 231);
			this->groupBox1->TabIndex = 10;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Matriz A";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(197, 176);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 41);
			this->button3->TabIndex = 10;
			this->button3->Text = L"Mostrar traspuesta";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->groupBox3);
			this->groupBox2->Controls->Add(this->dgvMatrizB);
			this->groupBox2->Controls->Add(this->tbFilasB);
			this->groupBox2->Controls->Add(this->button4);
			this->groupBox2->Controls->Add(this->button5);
			this->groupBox2->Controls->Add(this->tbColumnasB);
			this->groupBox2->Controls->Add(this->button6);
			this->groupBox2->Controls->Add(this->button7);
			this->groupBox2->Location = System::Drawing::Point(12, 248);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(455, 247);
			this->groupBox2->TabIndex = 11;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Matriz B : Resultado";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->button2);
			this->groupBox3->Controls->Add(this->btnMult);
			this->groupBox3->Controls->Add(this->btnSumar);
			this->groupBox3->Location = System::Drawing::Point(7, 176);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(265, 59);
			this->groupBox3->TabIndex = 9;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Operaciones entre matrices";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(89, 18);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 2;
			this->button2->Text = L"Restar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btnMult
			// 
			this->btnMult->Location = System::Drawing::Point(172, 19);
			this->btnMult->Name = L"btnMult";
			this->btnMult->Size = System::Drawing::Size(75, 23);
			this->btnMult->TabIndex = 1;
			this->btnMult->Text = L"Multiplicar";
			this->btnMult->UseVisualStyleBackColor = true;
			this->btnMult->Click += gcnew System::EventHandler(this, &Form1::btnMult_Click);
			// 
			// btnSumar
			// 
			this->btnSumar->Location = System::Drawing::Point(7, 20);
			this->btnSumar->Name = L"btnSumar";
			this->btnSumar->Size = System::Drawing::Size(75, 23);
			this->btnSumar->TabIndex = 0;
			this->btnSumar->Text = L"Sumar";
			this->btnSumar->UseVisualStyleBackColor = true;
			this->btnSumar->Click += gcnew System::EventHandler(this, &Form1::btnSumar_Click);
			// 
			// dgvMatrizB
			// 
			this->dgvMatrizB->AllowUserToAddRows = false;
			this->dgvMatrizB->AllowUserToDeleteRows = false;
			this->dgvMatrizB->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvMatrizB->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvMatrizB->ColumnHeadersVisible = false;
			this->dgvMatrizB->Location = System::Drawing::Point(6, 19);
			this->dgvMatrizB->Name = L"dgvMatrizB";
			this->dgvMatrizB->RowHeadersVisible = false;
			this->dgvMatrizB->Size = System::Drawing::Size(248, 150);
			this->dgvMatrizB->TabIndex = 4;
			// 
			// tbFilasB
			// 
			this->tbFilasB->Location = System::Drawing::Point(258, 19);
			this->tbFilasB->Name = L"tbFilasB";
			this->tbFilasB->Size = System::Drawing::Size(87, 20);
			this->tbFilasB->TabIndex = 0;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(364, 99);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(85, 30);
			this->button4->TabIndex = 8;
			this->button4->Text = L"Limpiar";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(362, 69);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(85, 24);
			this->button5->TabIndex = 6;
			this->button5->Text = L"Mostrar";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// tbColumnasB
			// 
			this->tbColumnasB->Location = System::Drawing::Point(258, 45);
			this->tbColumnasB->Name = L"tbColumnasB";
			this->tbColumnasB->Size = System::Drawing::Size(87, 20);
			this->tbColumnasB->TabIndex = 2;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(362, 19);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(87, 44);
			this->button6->TabIndex = 1;
			this->button6->Text = L"Guardar tama�o";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(260, 71);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(88, 58);
			this->button7->TabIndex = 5;
			this->button7->Text = L"Guardar matriz";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Form1::button7_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(485, 517);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Name = L"Form1";
			this->Text = L"Ejercicios 1 al 6";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvMatriz))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvMatrizB))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void btnGuardarMatriz_Click(System::Object^  sender, System::EventArgs^  e)
			 {
				 matrizA.guardarMatriz(dgvMatriz);
			 }
	private: System::Void btnFilas_Click(System::Object^  sender, System::EventArgs^  e)
			 {
				 matrizA.setFilas(Convert::ToInt32(tbFilas->Text));
				 matrizA.setColumnas(Convert::ToInt32(tbColumnas->Text));
				 dgvMatriz -> RowCount = matrizA.getFilas();
				 dgvMatriz -> ColumnCount = matrizA.getColumnas();
			 }
	private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 limpiarMatriz(dgvMatriz);
				 matrizA.mostrarMatriz(dgvMatriz);
			 }
	private: System::Void btnEliminarRepetidos_Click(System::Object^  sender, System::EventArgs^  e) 
			{
				matrizA.eliminarRepetidos();
			}
	private: System::Void btnLimpiar_Click(System::Object^  sender, System::EventArgs^  e)
			 {
				 matrizA.limpiarMatriz();
				 limpiarMatriz(dgvMatriz);
			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizA.contarElementosMatrizTSuperior();
			 }
	private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizB.setFilas(Convert::ToInt32(tbFilasB->Text));
				 matrizB.setColumnas(Convert::ToInt32(tbColumnasB->Text));
				 dgvMatrizB -> RowCount = matrizB.getFilas();
				 dgvMatrizB -> ColumnCount = matrizB.getColumnas();
			 }
	private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizB.guardarMatriz(dgvMatrizB);
			 }
	private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 limpiarMatriz(dgvMatrizB);
				 matrizB.mostrarMatriz(dgvMatrizB);
			 }
	private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizB.limpiarMatriz();
				 limpiarMatriz(dgvMatrizB);
			 }
	private: System::Void btnSumar_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizA.sumarMatrices(matrizB);
				 limpiarMatriz(dgvMatrizB);
				 matrizB.mostrarMatriz(dgvMatrizB);
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizA.restarMatrices(matrizB);
				 limpiarMatriz(dgvMatrizB);
				 matrizB.mostrarMatriz(dgvMatrizB);
			 }
	private: System::Void btnMult_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizA.multMatrices(matrizB);
				 limpiarMatriz(dgvMatrizB);
				 matrizA.mostrarMatriz(dgvMatrizB);
			 }
	private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 matrizA.matrizTraspuesta();
				 limpiarMatriz(dgvMatriz);
				 matrizA.mostrarMatriz(dgvMatriz);
			 }
};
}

