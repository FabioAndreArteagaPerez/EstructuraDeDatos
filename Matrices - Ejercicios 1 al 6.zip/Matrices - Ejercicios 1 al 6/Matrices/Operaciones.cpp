#include "StdAfx.h"
#include "Operaciones.h"

// METODOS PRIVADOS PERTENECIENTES AL VECTOR
void Operaciones::iniciarVector(Vector& arr){
	for(int i=0; i<N*N; i++)
		setValor(i, 0);
}

bool Operaciones::estaVisto(Vector& arr, int buscado, int tam){
	for(int i=0; i<tam; i++){
		if(getValor(i) == buscado)
			return true;
	}
	return false;
}

bool Operaciones::esMatrizTriangularSuperior(int& cantidadCeros){
	if(getFilas() != getColumnas())
		return false;

	cantidadCeros = 0;

	for(int i=0; i<getFilas(); i++){
		int index = i+1;
		for(int j=0; j<getColumnas(); j++){
			while(index < getFilas()){
				if(getValorMatriz(index, j) != 0)
					return false;
				index++;
				cantidadCeros++;
			}
		}
	}

	return true;
}

void Operaciones::copiarMatriz(Matriz& aCopiar){
	thisMatriz(aCopiar);
	setFilas(aCopiar.getFilas());
	setColumnas(aCopiar.getColumnas());
}

void Operaciones::copiarMatriz(Matriz& aCopiar, int filas){
	thisMatriz(aCopiar);
	setFilas(filas);
	setColumnas(aCopiar.getColumnas());
}

// METODOS PUBLICOS
Operaciones::Operaciones(void)
{
	Matriz();
	Vector();
}

void Operaciones::guardarMatriz(DataGridView^ dgv){
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++)
			setValorMatriz(i, j, Convert::ToInt32(dgv->Rows[i]->Cells[j]->Value));
	}
}

void Operaciones::mostrarMatriz(DataGridView^ dgv){
	dgv -> RowCount = getFilas();
	dgv -> ColumnCount = getColumnas();

	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++)
			dgv->Rows[i]->Cells[j]->Value = getValorMatriz(i, j);
	}
}

void Operaciones::limpiarMatriz(){
	setFilas(0);
	setColumnas(0);
}

void Operaciones::eliminarRepetidos(){
	Vector repetidos; 
	repetidos.setTam(N*N);
	iniciarVector(repetidos);
	int tam = 0;
	// GUARDAR UN SOLO VALOR POR CADA EXISTENTE EN LA MATRIZ
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++){
			if(!estaVisto(repetidos, getValorMatriz(i, j), tam)){
				repetidos.setValor(i, getValorMatriz(i, j));
				tam++;
			}
		}
	}
	// COPIAR ESOS VALORES EN LA MATRIZ MANTENIENDO LA CANTIDAD DE COLUMNAS
	Matriz aux;
	aux.setFilas(N);
	aux.setColumnas(getColumnas());

	int indexArray = 0;
	int filasCreadas = 0;
	bool terminado = false;
	for(; filasCreadas<aux.getFilas(); filasCreadas++){
		for(int j=0; j<aux.getColumnas(); j++){
			if(indexArray == tam){
				terminado = true;
				break;
			}
			aux.setValorMatriz(filasCreadas, j, repetidos.getValor(indexArray));
			indexArray++;
		}
		if(terminado)
			break;
	}

	copiarMatriz(aux, filasCreadas);
}

void Operaciones::contarElementosMatrizTSuperior(){
	int cantidadCeros = 0;
	if(!esMatrizTriangularSuperior(cantidadCeros))
		MessageBox::Show("No es matriz triangular superior", "Error");
	else
		MessageBox::Show("Cantidad de elementos: " + Convert::ToString(getFilas()*getColumnas()-cantidadCeros), "Matriz triangular superior");
}

void Operaciones::sumarMatrices(Matriz& matrizB){
	if(getFilas() != matrizB.getFilas()){
		MessageBox::Show("No se pueden sumar estar matrices", "Error");
		return;
	}

	if(getColumnas() != matrizB.getColumnas()){
		MessageBox::Show("No se pueden sumar estar matrices", "Error");
		return;
	}

	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++){
			matrizB.setValorMatriz(i, j, getValorMatriz(i, j) + matrizB.getValorMatriz(i, j));
		}
	}
}

void Operaciones::restarMatrices(Matriz& matrizB){
	if(getFilas() != matrizB.getFilas()){
		MessageBox::Show("No se pueden restar estar matrices", "Error");
		return;
	}

	if(getColumnas() != matrizB.getColumnas()){
		MessageBox::Show("No se pueden restar estar matrices", "Error");
		return;
	}

	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++){
			matrizB.setValorMatriz(i, j, getValorMatriz(i, j) - matrizB.getValorMatriz(i, j));
		}
	}
}

void Operaciones::multMatrices(Matriz& matrizB){
	if(getColumnas() != matrizB.getFilas()){
		MessageBox::Show("No se pueden multiplicar estar matrices", "Error");
		return;
	}

	Matriz resultado;
	resultado.setFilas(getFilas());
	resultado.setColumnas(matrizB.getColumnas());

	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<matrizB.getColumnas(); j++){
			int resParcial = 0;
			for(int k=0; k<getColumnas(); k++){
				resParcial += getValorMatriz(i, k) * matrizB.getValorMatriz(k, j);
			}
			resultado.setValorMatriz(i, j, resParcial);
		}
	}

	copiarMatriz(resultado);
}

void Operaciones::matrizTraspuesta(){
	Matriz resultado;
	resultado.setFilas(getColumnas());
	resultado.setColumnas(getFilas());

	for(int iA=0, jB=0; iA<getFilas(); iA++, jB++){
		for(int jA=0, iB=0; jA<getColumnas(); jA++, iB++)
			resultado.setValorMatriz(iB, jB, getValorMatriz(iA, jA));
	}

	copiarMatriz(resultado);
}