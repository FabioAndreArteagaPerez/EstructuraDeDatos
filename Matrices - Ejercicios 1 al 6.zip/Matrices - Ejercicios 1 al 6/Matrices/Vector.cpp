#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{
	tamano = 0;
	for(int i=0; i<TAM; i++)
		arr[i] = 0;
}

void Vector::setValor(int pos, int valor){
	arr[pos] = valor;
}

void Vector::setTam(int _tamano){
	tamano = _tamano;
}

int Vector::getValor(int pos){
	return arr[pos];
}

int Vector::getTam(){
	return tamano;
}