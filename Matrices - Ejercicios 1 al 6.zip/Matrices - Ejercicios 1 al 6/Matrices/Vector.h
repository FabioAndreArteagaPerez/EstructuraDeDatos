#pragma once

const int TAM = 25;

class Vector
{
	int arr[TAM];
	int tamano;
public:
	Vector(void);
	void setValor(int, int);
	void setTam(int);
	int getValor(int);
	int getTam();
};

