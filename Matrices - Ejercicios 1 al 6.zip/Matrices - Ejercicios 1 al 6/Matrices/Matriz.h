#pragma once

const int N = 5;

class Matriz
{
	int filas;
	int columnas;
	int matriz[N][N];
public:
	Matriz(void);
	void setFilas(int);
	void setColumnas(int);
	void setValorMatriz(int, int, int);

	int getFilas();
	int getColumnas();
	int getValorMatriz(int, int);

	Matriz thisMatriz(){
		return *this;
	}
	void thisMatriz(Matriz mat){
		*this = mat;
	}
};

