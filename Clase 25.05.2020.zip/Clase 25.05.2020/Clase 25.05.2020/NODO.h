#pragma once
class NODO
{
#pragma once 
#include "Dato.h"

class NODO { 
public: 
    Dato dato; 
    NODO *puntero;
public: 
	NODO();
	~NODO();
};