#include "StdAfx.h"
#include "NODO.h"


NODO::NODO()
{puntero = NULL; 
}

NODO::~NODO()
{ 
}


