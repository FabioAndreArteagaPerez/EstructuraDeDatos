#pragma once
#include "Operaciones.h"

namespace MatricesEjercicio9 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>

	Operaciones datos;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		void limpiarGrilla(DataGridView^ dgv){
			for(int i=0; i<dgv->RowCount; i++){
				for(int j=0; j<dgv->ColumnCount; j++){
					dgv->Rows[i]->Cells[j]->Value = "";
				}
			}
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  tbTrabajadores;
	private: System::Windows::Forms::Button^  btnTrabajadores;
	protected: 

	protected: 

	private: System::Windows::Forms::DataGridView^  dgvTrabajadores;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridView^  dgvResultados;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column5;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column6;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::Button^  btnGuardar;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tbTrabajadores = (gcnew System::Windows::Forms::TextBox());
			this->btnTrabajadores = (gcnew System::Windows::Forms::Button());
			this->dgvTrabajadores = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dgvResultados = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column5 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column6 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->btnGuardar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvTrabajadores))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvResultados))->BeginInit();
			this->SuspendLayout();
			// 
			// tbTrabajadores
			// 
			this->tbTrabajadores->Location = System::Drawing::Point(371, 12);
			this->tbTrabajadores->Name = L"tbTrabajadores";
			this->tbTrabajadores->Size = System::Drawing::Size(83, 20);
			this->tbTrabajadores->TabIndex = 0;
			// 
			// btnTrabajadores
			// 
			this->btnTrabajadores->Location = System::Drawing::Point(371, 38);
			this->btnTrabajadores->Name = L"btnTrabajadores";
			this->btnTrabajadores->Size = System::Drawing::Size(83, 19);
			this->btnTrabajadores->TabIndex = 1;
			this->btnTrabajadores->Text = L"Trabajadores";
			this->btnTrabajadores->UseVisualStyleBackColor = true;
			this->btnTrabajadores->Click += gcnew System::EventHandler(this, &Form1::btnTrabajadores_Click);
			// 
			// dgvTrabajadores
			// 
			this->dgvTrabajadores->AllowUserToAddRows = false;
			this->dgvTrabajadores->AllowUserToDeleteRows = false;
			this->dgvTrabajadores->AllowUserToResizeColumns = false;
			this->dgvTrabajadores->AllowUserToResizeRows = false;
			this->dgvTrabajadores->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvTrabajadores->AutoSizeRowsMode = System::Windows::Forms::DataGridViewAutoSizeRowsMode::AllCells;
			this->dgvTrabajadores->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvTrabajadores->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, 
				this->Column2, this->Column3});
			this->dgvTrabajadores->Location = System::Drawing::Point(13, 12);
			this->dgvTrabajadores->Name = L"dgvTrabajadores";
			this->dgvTrabajadores->RowHeadersVisible = false;
			this->dgvTrabajadores->Size = System::Drawing::Size(352, 109);
			this->dgvTrabajadores->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Codigo";
			this->Column1->Name = L"Column1";
			this->Column1->Width = 65;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Horas normales";
			this->Column2->Name = L"Column2";
			this->Column2->Width = 96;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Horas extras";
			this->Column3->Name = L"Column3";
			this->Column3->Width = 84;
			// 
			// dgvResultados
			// 
			this->dgvResultados->AllowUserToAddRows = false;
			this->dgvResultados->AllowUserToDeleteRows = false;
			this->dgvResultados->AllowUserToResizeColumns = false;
			this->dgvResultados->AllowUserToResizeRows = false;
			this->dgvResultados->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvResultados->AutoSizeRowsMode = System::Windows::Forms::DataGridViewAutoSizeRowsMode::AllCells;
			this->dgvResultados->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvResultados->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(6) {this->dataGridViewTextBoxColumn1, 
				this->dataGridViewTextBoxColumn2, this->Column4, this->dataGridViewTextBoxColumn3, this->Column5, this->Column6});
			this->dgvResultados->Location = System::Drawing::Point(13, 141);
			this->dgvResultados->Name = L"dgvResultados";
			this->dgvResultados->RowHeadersVisible = false;
			this->dgvResultados->Size = System::Drawing::Size(556, 108);
			this->dgvResultados->TabIndex = 3;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Codigo";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			this->dataGridViewTextBoxColumn1->Width = 65;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this->dataGridViewTextBoxColumn2->HeaderText = L"Horas normales";
			this->dataGridViewTextBoxColumn2->Name = L"dataGridViewTextBoxColumn2";
			this->dataGridViewTextBoxColumn2->Width = 96;
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Pago horas/normales";
			this->Column4->Name = L"Column4";
			this->Column4->Width = 122;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this->dataGridViewTextBoxColumn3->HeaderText = L"Horas extras";
			this->dataGridViewTextBoxColumn3->Name = L"dataGridViewTextBoxColumn3";
			this->dataGridViewTextBoxColumn3->Width = 84;
			// 
			// Column5
			// 
			this->Column5->HeaderText = L"Pago horas/extras";
			this->Column5->Name = L"Column5";
			this->Column5->Width = 109;
			// 
			// Column6
			// 
			this->Column6->HeaderText = L"Pago total";
			this->Column6->Name = L"Column6";
			this->Column6->Width = 74;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(494, 98);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// btnGuardar
			// 
			this->btnGuardar->Location = System::Drawing::Point(494, 12);
			this->btnGuardar->Name = L"btnGuardar";
			this->btnGuardar->Size = System::Drawing::Size(75, 23);
			this->btnGuardar->TabIndex = 5;
			this->btnGuardar->Text = L"Guardar";
			this->btnGuardar->UseVisualStyleBackColor = true;
			this->btnGuardar->Click += gcnew System::EventHandler(this, &Form1::btnGuardar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(597, 261);
			this->Controls->Add(this->btnGuardar);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->dgvResultados);
			this->Controls->Add(this->dgvTrabajadores);
			this->Controls->Add(this->btnTrabajadores);
			this->Controls->Add(this->tbTrabajadores);
			this->Name = L"Form1";
			this->Text = L"Ejercicio 9";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvTrabajadores))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvResultados))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTrabajadores_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 limpiarGrilla(dgvTrabajadores);
				 datos.setFilas(Convert::ToInt32(tbTrabajadores->Text));
				 datos.setColumnas(3);
				 dgvTrabajadores -> RowCount = datos.getFilas();
			 }
private: System::Void btnGuardar_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.guardarDatos(dgvTrabajadores);
		 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.resultado(dgvResultados);
		 }
};
}

