#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	filas = 0;
	columnas = 0;
}

void Matriz::setValorMatriz(int f, int c, int valor){
	matriz[f][c] = valor;
}

void Matriz::setFilas(int _filas){
	filas = _filas;
}

void Matriz::setColumnas(int _columnas){
	columnas = _columnas;
}

int Matriz::getValorMatriz(int f, int c){
	return matriz[f][c];
}

int Matriz::getFilas(){
	return filas;
}

int Matriz::getColumnas(){
	return columnas;
}