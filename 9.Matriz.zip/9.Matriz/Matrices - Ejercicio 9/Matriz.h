#pragma once

const int N = 20;

class Matriz
{
	int matriz[N][N];
	int filas;
	int columnas;
public:
	Matriz(void);
	void setValorMatriz(int, int, int);
	void setFilas(int);
	void setColumnas(int);

	int getValorMatriz(int, int);
	int getFilas();
	int getColumnas();
};

