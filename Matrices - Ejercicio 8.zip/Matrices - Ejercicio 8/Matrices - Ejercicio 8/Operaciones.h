#pragma once
#include "Matriz.h"
#include "Vector.h"
#include <msclr\marshal_cppstd.h>

using namespace System;
using namespace msclr::interop;
using namespace System::Windows::Forms;

class Operaciones : public Matriz, public Vector
{
	void llenarVector(Vector&);
	void llenarVector(Vector&, int);
	void promedioPorFila(Vector&);
	void promedioPorColumna(Vector&);
public:
	Operaciones(void);

	void guardarDatos(DataGridView^);

	void notaPromedioEstudiantes(DataGridView^);
	void cantidadDeAprobados();
	void cantidadDeReprobados();
	void notaPromedioMaterias(DataGridView^);

};

