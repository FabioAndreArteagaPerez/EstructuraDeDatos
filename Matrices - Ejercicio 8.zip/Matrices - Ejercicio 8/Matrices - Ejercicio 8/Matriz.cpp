#include "StdAfx.h"
#include "Matriz.h"


Matriz::Matriz(void)
{
	filas = 0;
	for(int i=0; i<N; i++){
		for(int j=0; j<6; j++)
			matriz[i][j] = -1;
	}
}

void Matriz::setFilas(int _filas){
	filas = _filas;
}

void Matriz::setValorMatriz(int f, int c, double valor){
	matriz[f][c] = valor;
}

int Matriz::getFilas(){
	return filas;
}

double Matriz::getValorMatriz(int f, int c){
	return matriz[f][c];
}

