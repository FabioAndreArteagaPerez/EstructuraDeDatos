#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{
	tam = 0;
}

void Vector::setValor(int pos, double valor){
	arr[pos] = valor;
}

void Vector::setTam(int _tam){
	tam = _tam;
}

double Vector::getValor(int pos){
	return arr[pos];
}

int Vector::getTam(){
	return tam;
}