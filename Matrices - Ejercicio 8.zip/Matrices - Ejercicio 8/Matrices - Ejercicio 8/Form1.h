#pragma once
#include "Operaciones.h"

namespace MatricesEjercicio8 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>

	Operaciones datos;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dgvDatos;
	private: System::Windows::Forms::TextBox^  tbAlumnos;
	private: System::Windows::Forms::Button^  btnAsignar;
	private: System::Windows::Forms::Button^  btnGuardar;
	private: System::Windows::Forms::Button^  btnPromEst;
	private: System::Windows::Forms::Button^  btnAprobados;
	private: System::Windows::Forms::Button^  btnReprobados;
	private: System::Windows::Forms::Button^  btnPromMat;
	private: System::Windows::Forms::Label^  label1;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dgvDatos = (gcnew System::Windows::Forms::DataGridView());
			this->tbAlumnos = (gcnew System::Windows::Forms::TextBox());
			this->btnAsignar = (gcnew System::Windows::Forms::Button());
			this->btnGuardar = (gcnew System::Windows::Forms::Button());
			this->btnPromEst = (gcnew System::Windows::Forms::Button());
			this->btnAprobados = (gcnew System::Windows::Forms::Button());
			this->btnReprobados = (gcnew System::Windows::Forms::Button());
			this->btnPromMat = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvDatos))->BeginInit();
			this->SuspendLayout();
			// 
			// dgvDatos
			// 
			this->dgvDatos->AllowUserToAddRows = false;
			this->dgvDatos->AllowUserToDeleteRows = false;
			this->dgvDatos->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dgvDatos->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvDatos->Location = System::Drawing::Point(13, 13);
			this->dgvDatos->Name = L"dgvDatos";
			this->dgvDatos->Size = System::Drawing::Size(240, 181);
			this->dgvDatos->TabIndex = 0;
			this->dgvDatos->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dgvDatos_CellContentClick);
			// 
			// tbAlumnos
			// 
			this->tbAlumnos->Location = System::Drawing::Point(260, 13);
			this->tbAlumnos->Name = L"tbAlumnos";
			this->tbAlumnos->Size = System::Drawing::Size(75, 20);
			this->tbAlumnos->TabIndex = 1;
			// 
			// btnAsignar
			// 
			this->btnAsignar->Location = System::Drawing::Point(342, 13);
			this->btnAsignar->Name = L"btnAsignar";
			this->btnAsignar->Size = System::Drawing::Size(66, 23);
			this->btnAsignar->TabIndex = 2;
			this->btnAsignar->Text = L"Asignar";
			this->btnAsignar->UseVisualStyleBackColor = true;
			this->btnAsignar->Click += gcnew System::EventHandler(this, &Form1::btnAsignar_Click);
			// 
			// btnGuardar
			// 
			this->btnGuardar->Location = System::Drawing::Point(260, 40);
			this->btnGuardar->Name = L"btnGuardar";
			this->btnGuardar->Size = System::Drawing::Size(148, 23);
			this->btnGuardar->TabIndex = 3;
			this->btnGuardar->Text = L"Guardar datos";
			this->btnGuardar->UseVisualStyleBackColor = true;
			this->btnGuardar->Click += gcnew System::EventHandler(this, &Form1::btnGuardar_Click);
			// 
			// btnPromEst
			// 
			this->btnPromEst->Location = System::Drawing::Point(260, 70);
			this->btnPromEst->Name = L"btnPromEst";
			this->btnPromEst->Size = System::Drawing::Size(148, 23);
			this->btnPromEst->TabIndex = 4;
			this->btnPromEst->Text = L"Promedio/estudiante";
			this->btnPromEst->UseVisualStyleBackColor = true;
			this->btnPromEst->Click += gcnew System::EventHandler(this, &Form1::btnPromEst_Click);
			// 
			// btnAprobados
			// 
			this->btnAprobados->Location = System::Drawing::Point(260, 100);
			this->btnAprobados->Name = L"btnAprobados";
			this->btnAprobados->Size = System::Drawing::Size(148, 23);
			this->btnAprobados->TabIndex = 5;
			this->btnAprobados->Text = L"Aprobados";
			this->btnAprobados->UseVisualStyleBackColor = true;
			this->btnAprobados->Click += gcnew System::EventHandler(this, &Form1::btnAprobados_Click);
			// 
			// btnReprobados
			// 
			this->btnReprobados->Location = System::Drawing::Point(260, 130);
			this->btnReprobados->Name = L"btnReprobados";
			this->btnReprobados->Size = System::Drawing::Size(148, 23);
			this->btnReprobados->TabIndex = 6;
			this->btnReprobados->Text = L"Reprobados";
			this->btnReprobados->UseVisualStyleBackColor = true;
			this->btnReprobados->Click += gcnew System::EventHandler(this, &Form1::btnReprobados_Click);
			// 
			// btnPromMat
			// 
			this->btnPromMat->Location = System::Drawing::Point(260, 160);
			this->btnPromMat->Name = L"btnPromMat";
			this->btnPromMat->Size = System::Drawing::Size(148, 23);
			this->btnPromMat->TabIndex = 7;
			this->btnPromMat->Text = L"Promedio/materia";
			this->btnPromMat->UseVisualStyleBackColor = true;
			this->btnPromMat->Click += gcnew System::EventHandler(this, &Form1::btnPromMat_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(13, 204);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(237, 13);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Para otros valores, solo asigne un nuevo tama�o";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(420, 229);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnPromMat);
			this->Controls->Add(this->btnReprobados);
			this->Controls->Add(this->btnAprobados);
			this->Controls->Add(this->btnPromEst);
			this->Controls->Add(this->btnGuardar);
			this->Controls->Add(this->btnAsignar);
			this->Controls->Add(this->tbAlumnos);
			this->Controls->Add(this->dgvDatos);
			this->Name = L"Form1";
			this->Text = L"Ejercicio 8";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvDatos))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dgvDatos_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
	private: System::Void btnAsignar_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 datos.setFilas(Convert::ToInt32(tbAlumnos->Text));
				 dgvDatos -> RowCount = datos.getFilas();
				 dgvDatos -> ColumnCount = 6;
			 }
private: System::Void btnGuardar_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.guardarDatos(dgvDatos);
		 }
private: System::Void btnPromEst_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.notaPromedioEstudiantes(dgvDatos);
		 }
private: System::Void btnAprobados_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.cantidadDeAprobados();
		 }
private: System::Void btnReprobados_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.cantidadDeReprobados();
		 }
private: System::Void btnPromMat_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 datos.notaPromedioMaterias(dgvDatos);
		 }
};
}

