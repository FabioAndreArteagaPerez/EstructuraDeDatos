#pragma once

const int N = 20;

class Matriz{
	int filas;
	double matriz[N][6];
public:
	Matriz(void);

	void setFilas(int);
	void setValorMatriz(int, int, double);
	int getFilas();
	double getValorMatriz(int, int);
};

