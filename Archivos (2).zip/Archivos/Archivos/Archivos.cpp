// Archivos.cpp : main project file.

#include "stdafx.h"

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void main() {
	ABMamigo *amig = new ABMamigo("amigOO.dat");
	/*amig->adicionarNuevo();
	amig->listar();
	amig->buscarReg();
	amig->eliminarReg();
	amig->modificarReg();
	amig->listar();
	getch();*/
	int opc;
	do
	{do
		{cout<<"\nMENU\n";
		cout<<"Ingrese nro entre 1 y 6: ";
		cin>>opc;
		}while(opc<1||opc>7);
	switch(opc)
		{case 1:amig->adicionarNuevo();
				break;
		 case 2:amig->listar();
				break;
		 case 3:amig->buscarReg();
				break;
		case 4:amig->eliminarReg();
				break;
		case 5:amig->modificarReg();
				break;
		 case 6:cout<<"Adios";
				_getch();
		}
	}while(opc!=6);

}

