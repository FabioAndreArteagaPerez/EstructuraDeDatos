#include "StdAfx.h"
#include "Operaciones.h"

// METODOS PRIVADOS
bool Operaciones::estaVisto(string elemento){
	Pila aux;
	aux = thisPila();

	while(!aux.estaVacia()){
		string elem;
		aux.eliminar(elem);
		if(elem == elemento)
			return true;
	}
	return false;
}

// METODOS PUBLICOS
Operaciones::Operaciones(void)
{
	Pila();
}

void Operaciones::guardarPila(DataGridView^ dgv){
	for(int i=0; i<dgv->RowCount; i++)
		insertar(marshal_as<string>(Convert::ToString(dgv->Rows[i]->Cells[0]->Value)));
}

void Operaciones::mostrarPila(DataGridView^ dgv){
	if(!estaVacia()){
		dgv -> RowCount = getTope() + 1;
		string elemento;
		Pila aux;
		int i=0;
		while(!estaVacia()){
			eliminar(elemento);
			aux.insertar(elemento);
			dgv->Rows[i]->Cells[0]->Value = marshal_as<String^>(elemento);
			i++;
		}

		while(!aux.estaVacia()){
			aux.eliminar(elemento);
			insertar(elemento);
		}
	}
	else
		MessageBox::Show("Pila vacia", "Error");
}

void Operaciones::eliminarPila(DataGridView^ dgv1, DataGridView^ dgv2){
	dgv1 -> RowCount = 0;
	dgv2 -> RowCount = 0;

	while(!estaVacia()){
		string aux;
		eliminar(aux);
	}
}

void Operaciones::eliminarElemento(string eliminarElemento){
	Pila aux;
	string eliminado;
	while(!estaVacia()){
		eliminar(eliminado);
		if(eliminado != eliminarElemento)
			aux.insertar(eliminado);
	}
	while(!aux.estaVacia()){
		string elemento;
		aux.eliminar(elemento);
		insertar(elemento);
	}
}

void Operaciones::contarElementos(){
	Pila aux; 
	aux = thisPila();

	if(!aux.estaVacia()){
		int cantidad = 0;
		while(!aux.estaVacia()){
			string elemento;
			aux.eliminar(elemento);
			cantidad++;
		}
		MessageBox::Show("Cantidad de elementos: " + Convert::ToString(cantidad));
	}else
		MessageBox::Show("Pila vacia");
}

void Operaciones::invertirPila(){
	Pila aux;

	if(!estaVacia()){
		while(!estaVacia()){
			string elemento;
			eliminar(elemento);
			aux.insertar(elemento);
		}
		thisPila(aux);
	}else
		MessageBox::Show("Pila vacia");
}

void Operaciones::eliminarPosicion(int n){
	Pila aux;
	int index = getTope();

	if(!estaVacia()){
		while(!estaVacia()){
			string elemento;
			eliminar(elemento);
			if(index != n)
				aux.insertar(elemento);
			else
				break;
			index--;
		}

		while(!aux.estaVacia()){
			string elemento;
			aux.eliminar(elemento);
			insertar(elemento);
		}
	}else
		MessageBox::Show("Pila vacia");
}

void Operaciones::eliminarPares(){
	Pila aux;

	while(!estaVacia()){
		string elemento;
		eliminar(elemento);
		if(Convert::ToInt32(marshal_as<String^>(elemento)) % 2 != 0)
			aux.insertar(elemento);
	}

	thisPila(aux);
}

void Operaciones::eliminarRepetidos(){
	Pila aux;

	while(!estaVacia()){
		string elemento;
		eliminar(elemento);
		if(!estaVisto(elemento))
			aux.insertar(elemento);
	}

	thisPila(aux);
}