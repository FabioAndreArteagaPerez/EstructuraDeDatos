#pragma once
#include <string>

class Nodo
{
	string elemento;
public:
	Nodo(void);
};

