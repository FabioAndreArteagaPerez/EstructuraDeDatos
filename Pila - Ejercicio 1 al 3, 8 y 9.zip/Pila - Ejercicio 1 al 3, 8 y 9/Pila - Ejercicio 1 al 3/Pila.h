#pragma once
#include <string>

using namespace std;

const int N = 40;

class Pila
{
	string arr[N];
	int tope;
public:
	Pila(void);
	bool insertar(string);
	bool eliminar(string&);
	int getTope();
	bool estaVacia();
	bool estaLlena();
	
	Pila thisPila(){
		return *this;
	}
	void thisPila(Pila p){
		*this = p;
	}
};

