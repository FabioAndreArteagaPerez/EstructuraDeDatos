#pragma once
#include "Operaciones.h"
#include <msclr\marshal_cppstd.h>
namespace PilaEjercicio1al3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	/// <summary>
	/// Summary for Form1
	/// </summary>

	Operaciones pila;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dgvPila1;
	protected: 

	protected: 
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  btnTam;
	private: System::Windows::Forms::TextBox^  tbTam;
	private: System::Windows::Forms::Button^  btnInsertar;
	private: System::Windows::Forms::Button^  btnMostrar;
	private: System::Windows::Forms::Button^  btnEliminar;
	private: System::Windows::Forms::DataGridView^  dgvPila2;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::TextBox^  tbElemento;
	private: System::Windows::Forms::Button^  btnElimarElemento;
	private: System::Windows::Forms::Button^  btnContar;
	private: System::Windows::Forms::Button^  btnInvertir;
	private: System::Windows::Forms::TextBox^  tbEliminarN;
	private: System::Windows::Forms::Button^  btnEliminarN;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  btnElimRep;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dgvPila1 = (gcnew System::Windows::Forms::DataGridView());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			this->tbTam = (gcnew System::Windows::Forms::TextBox());
			this->btnInsertar = (gcnew System::Windows::Forms::Button());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			this->btnEliminar = (gcnew System::Windows::Forms::Button());
			this->dgvPila2 = (gcnew System::Windows::Forms::DataGridView());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->tbElemento = (gcnew System::Windows::Forms::TextBox());
			this->btnElimarElemento = (gcnew System::Windows::Forms::Button());
			this->btnContar = (gcnew System::Windows::Forms::Button());
			this->btnInvertir = (gcnew System::Windows::Forms::Button());
			this->tbEliminarN = (gcnew System::Windows::Forms::TextBox());
			this->btnEliminarN = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->btnElimRep = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvPila1))->BeginInit();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvPila2))->BeginInit();
			this->groupBox2->SuspendLayout();
			this->SuspendLayout();
			// 
			// dgvPila1
			// 
			this->dgvPila1->AllowUserToAddRows = false;
			this->dgvPila1->AllowUserToDeleteRows = false;
			this->dgvPila1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvPila1->ColumnHeadersVisible = false;
			this->dgvPila1->Location = System::Drawing::Point(6, 16);
			this->dgvPila1->Name = L"dgvPila1";
			this->dgvPila1->RowHeadersVisible = false;
			this->dgvPila1->Size = System::Drawing::Size(103, 313);
			this->dgvPila1->TabIndex = 0;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->dgvPila1);
			this->groupBox1->Location = System::Drawing::Point(13, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(118, 344);
			this->groupBox1->TabIndex = 1;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Pila 1";
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(137, 54);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 2;
			this->btnTam->Text = L"Tama�o";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// tbTam
			// 
			this->tbTam->Location = System::Drawing::Point(137, 28);
			this->tbTam->Name = L"tbTam";
			this->tbTam->Size = System::Drawing::Size(75, 20);
			this->tbTam->TabIndex = 3;
			// 
			// btnInsertar
			// 
			this->btnInsertar->Location = System::Drawing::Point(138, 83);
			this->btnInsertar->Name = L"btnInsertar";
			this->btnInsertar->Size = System::Drawing::Size(75, 23);
			this->btnInsertar->TabIndex = 4;
			this->btnInsertar->Text = L"Insertar";
			this->btnInsertar->UseVisualStyleBackColor = true;
			this->btnInsertar->Click += gcnew System::EventHandler(this, &Form1::btnInsertar_Click);
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(139, 113);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(75, 23);
			this->btnMostrar->TabIndex = 5;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// btnEliminar
			// 
			this->btnEliminar->Location = System::Drawing::Point(139, 143);
			this->btnEliminar->Name = L"btnEliminar";
			this->btnEliminar->Size = System::Drawing::Size(75, 23);
			this->btnEliminar->TabIndex = 6;
			this->btnEliminar->Text = L"Eliminar";
			this->btnEliminar->UseVisualStyleBackColor = true;
			this->btnEliminar->Click += gcnew System::EventHandler(this, &Form1::btnEliminar_Click);
			// 
			// dgvPila2
			// 
			this->dgvPila2->AllowUserToAddRows = false;
			this->dgvPila2->AllowUserToDeleteRows = false;
			this->dgvPila2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvPila2->ColumnHeadersVisible = false;
			this->dgvPila2->Location = System::Drawing::Point(6, 16);
			this->dgvPila2->Name = L"dgvPila2";
			this->dgvPila2->RowHeadersVisible = false;
			this->dgvPila2->Size = System::Drawing::Size(103, 313);
			this->dgvPila2->TabIndex = 7;
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->dgvPila2);
			this->groupBox2->Location = System::Drawing::Point(241, 12);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(118, 344);
			this->groupBox2->TabIndex = 8;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Pila 2";
			// 
			// tbElemento
			// 
			this->tbElemento->Location = System::Drawing::Point(138, 172);
			this->tbElemento->Name = L"tbElemento";
			this->tbElemento->Size = System::Drawing::Size(75, 20);
			this->tbElemento->TabIndex = 9;
			// 
			// btnElimarElemento
			// 
			this->btnElimarElemento->Location = System::Drawing::Point(138, 199);
			this->btnElimarElemento->Name = L"btnElimarElemento";
			this->btnElimarElemento->Size = System::Drawing::Size(75, 23);
			this->btnElimarElemento->TabIndex = 10;
			this->btnElimarElemento->Text = L"Eliminar uno";
			this->btnElimarElemento->UseVisualStyleBackColor = true;
			this->btnElimarElemento->Click += gcnew System::EventHandler(this, &Form1::btnElimarElemento_Click);
			// 
			// btnContar
			// 
			this->btnContar->Location = System::Drawing::Point(139, 229);
			this->btnContar->Name = L"btnContar";
			this->btnContar->Size = System::Drawing::Size(75, 39);
			this->btnContar->TabIndex = 11;
			this->btnContar->Text = L"Contar elementos";
			this->btnContar->UseVisualStyleBackColor = true;
			this->btnContar->Click += gcnew System::EventHandler(this, &Form1::btnContar_Click);
			// 
			// btnInvertir
			// 
			this->btnInvertir->Location = System::Drawing::Point(139, 275);
			this->btnInvertir->Name = L"btnInvertir";
			this->btnInvertir->Size = System::Drawing::Size(75, 23);
			this->btnInvertir->TabIndex = 12;
			this->btnInvertir->Text = L"Invertir";
			this->btnInvertir->UseVisualStyleBackColor = true;
			this->btnInvertir->Click += gcnew System::EventHandler(this, &Form1::btnInvertir_Click);
			// 
			// tbEliminarN
			// 
			this->tbEliminarN->Location = System::Drawing::Point(139, 365);
			this->tbEliminarN->Name = L"tbEliminarN";
			this->tbEliminarN->Size = System::Drawing::Size(100, 20);
			this->tbEliminarN->TabIndex = 13;
			// 
			// btnEliminarN
			// 
			this->btnEliminarN->Location = System::Drawing::Point(19, 362);
			this->btnEliminarN->Name = L"btnEliminarN";
			this->btnEliminarN->Size = System::Drawing::Size(112, 23);
			this->btnEliminarN->TabIndex = 14;
			this->btnEliminarN->Text = L"Eliminar elemento";
			this->btnEliminarN->UseVisualStyleBackColor = true;
			this->btnEliminarN->Click += gcnew System::EventHandler(this, &Form1::btnEliminarN_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(139, 305);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 36);
			this->button1->TabIndex = 15;
			this->button1->Text = L"Eliminar pares";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// btnElimRep
			// 
			this->btnElimRep->Location = System::Drawing::Point(247, 361);
			this->btnElimRep->Name = L"btnElimRep";
			this->btnElimRep->Size = System::Drawing::Size(112, 23);
			this->btnElimRep->TabIndex = 16;
			this->btnElimRep->Text = L"Eliminar repetidos";
			this->btnElimRep->UseVisualStyleBackColor = true;
			this->btnElimRep->Click += gcnew System::EventHandler(this, &Form1::btnElimRep_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(376, 393);
			this->Controls->Add(this->btnElimRep);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnEliminarN);
			this->Controls->Add(this->tbEliminarN);
			this->Controls->Add(this->btnInvertir);
			this->Controls->Add(this->btnContar);
			this->Controls->Add(this->btnElimarElemento);
			this->Controls->Add(this->tbElemento);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->btnEliminar);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->btnInsertar);
			this->Controls->Add(this->tbTam);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Name = L"Form1";
			this->Text = L"Ejercicios 1,2,3,8,9";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvPila1))->EndInit();
			this->groupBox1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvPila2))->EndInit();
			this->groupBox2->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) 
			{
				dgvPila1 -> RowCount = Convert::ToInt32(tbTam->Text);
			}
private: System::Void btnInsertar_Click(System::Object^  sender, System::EventArgs^  e) 
			{
				pila.guardarPila(dgvPila1);
			}
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e)
			{
				pila.mostrarPila(dgvPila2);
			}
private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) 
			{
				pila.eliminarPila(dgvPila1, dgvPila2);
			}
private: System::Void btnElimarElemento_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.eliminarElemento(marshal_as<string>(Convert::ToString(tbElemento->Text)));
			 }
private: System::Void btnContar_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.contarElementos();
			 }
private: System::Void btnInvertir_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.invertirPila();
			 }
private: System::Void btnEliminarN_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.eliminarPosicion(Convert::ToInt32(tbEliminarN->Text)); //corregir nombres y arg
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.eliminarPares();
			 }	
private: System::Void btnElimRep_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 pila.eliminarRepetidos();
			 }
};
}

