#pragma once
#include "Pila.h"
#include <string>
#include <msclr\marshal_cppstd.h>

using namespace std;
using namespace System;
using namespace System::Windows::Forms;
using namespace msclr::interop;

class Operaciones : public Pila
{
	bool estaVisto(string);
public:
	Operaciones(void);
	void guardarPila(DataGridView^);  
	void mostrarPila(DataGridView^);  
	void eliminarPila(DataGridView^, DataGridView^);  
	void eliminarElemento(string);  
	void contarElementos();  
	void invertirPila();  
	void eliminarPosicion(int);  
	void eliminarPares();  
	void eliminarRepetidos();  
};

