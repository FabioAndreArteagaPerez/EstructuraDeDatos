#include "StdAfx.h"
#include "Pila.h"


Pila::Pila(void)
{
	tope = -1;
}

bool Pila::insertar(string elemento){
	if(estaLlena())
		return false;
	
	tope++;
	arr[tope] = elemento;
	return true;
}

bool Pila::eliminar(string& elemento){
	if(estaVacia())
		return false;
	elemento = arr[tope];
	tope--;
	return true;
}

int Pila::getTope(){
	return tope;
}

bool Pila::estaVacia(){
	return tope == -1;
}

bool Pila::estaLlena(){
	return tope == N;
}

