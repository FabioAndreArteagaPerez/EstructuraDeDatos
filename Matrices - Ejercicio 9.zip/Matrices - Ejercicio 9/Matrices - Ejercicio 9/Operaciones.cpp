#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
	Matriz();
}

void Operaciones::guardarDatos(DataGridView^ dgv){
	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++){
			setValorMatriz(i, j, Convert::ToInt32(dgv->Rows[i]->Cells[j]->Value));
		}
	}

	mostrarDatos(dgv);
}

void Operaciones::mostrarDatos(DataGridView^ dgv){
	dgv -> RowCount = getFilas();
	dgv -> ColumnCount = getColumnas();

	for(int i=0; i<getFilas(); i++){
		for(int j=0; j<getColumnas(); j++)
			dgv->Rows[i]->Cells[j]->Value = getValorMatriz(i, j);
	}
}

void Operaciones::resultado(DataGridView^ dgv){
	setColumnas(6);
	dgv -> RowCount = getFilas();
	dgv -> ColumnCount = getColumnas();

	int f = 0, c = 2;
	while(f < getFilas()){
		setValorMatriz(f, c+1, getValorMatriz(f, c));
		f++;
	}

	for(int i=0; i<getFilas(); i++){
		setValorMatriz(i, 2, getValorMatriz(i, 1) * 2350);
	}

	for(int i=0; i<getFilas(); i++){
		setValorMatriz(i, 4, getValorMatriz(i, 3) * 3500);
	}

	for(int i=0; i<getFilas(); i++){
		setValorMatriz(i, 5, getValorMatriz(i, 2) + getValorMatriz(i, 4));
	}

	mostrarDatos(dgv);
}

