#pragma once
#include "Matriz.h"
#include <msclr\marshal_cppstd.h>

using namespace System;
using namespace System::Windows::Forms;
using namespace msclr::interop;

class Operaciones : public Matriz
{
public:
	Operaciones(void);

	void guardarDatos(DataGridView^);
	void mostrarDatos(DataGridView^);

	void resultado(DataGridView^);
};

